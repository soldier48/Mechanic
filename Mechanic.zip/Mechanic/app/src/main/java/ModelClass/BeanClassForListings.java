package ModelClass;

/**
 * Created by Remmss on 11-09-17.
 */

public class BeanClassForListings {

    String lising_name;

    public BeanClassForListings(String lising_name) {
        this.lising_name = lising_name;

    }

    public String getLising_name() {
        return lising_name;
    }

    public void setLising_name(String lising_name) {
        this.lising_name = lising_name;
    }
}
