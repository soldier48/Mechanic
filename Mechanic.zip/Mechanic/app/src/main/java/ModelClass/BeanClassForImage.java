package ModelClass;

/**
 * Created by Remmss on 11-09-17.
 */

public class BeanClassForImage {

    int image;

    public BeanClassForImage(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
