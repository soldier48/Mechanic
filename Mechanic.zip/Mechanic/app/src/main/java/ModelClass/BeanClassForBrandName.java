package ModelClass;

/**
 * Created by Remmss on 12-09-17.
 */

public class BeanClassForBrandName {

    String brand_name;

    public BeanClassForBrandName(String brand_name) {
        this.brand_name = brand_name;
    }

    public String getBrand_name() {
        return brand_name;
    }

    public void setBrand_name(String brand_name) {
        this.brand_name = brand_name;
    }
}
