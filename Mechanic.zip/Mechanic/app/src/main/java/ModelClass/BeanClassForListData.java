package ModelClass;

/**
 * Created by Remmss on 07-09-17.
 */

public class BeanClassForListData {

    String name;

    public BeanClassForListData(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
