package ModelClass;

/**
 * Created by Wolf Soft on 9/11/2017.
 */

public class BeanClassForCart {

    int image;

    public BeanClassForCart(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
