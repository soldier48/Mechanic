package ModelClass;

/**
 * Created by Remmss on 07-09-17.
 */

public class BeanClassForTagData {

    String tag_name;

    public BeanClassForTagData(String tag_name) {
        this.tag_name = tag_name;
    }

    public String getTag_name() {
        return tag_name;
    }

    public void setTag_name(String tag_name) {
        this.tag_name = tag_name;
    }
}
