package ModelClass;

/**
 * Created by praja on 16-06-17.
 */

public class BeanClassForBuySellData {

    String challange;

    public BeanClassForBuySellData(String challange) {

        this.challange = challange;
    }

    public String getChallange() {
        return challange;
    }

    public void setChallange(String challange) {
        this.challange = challange;
    }
}
