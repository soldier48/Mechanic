package ModelClass;

/**
 * Created by Remmss on 09-09-17.
 */

public class BeanClassForCompaniesList {

    int img;

    public BeanClassForCompaniesList(int img) {
        this.img = img;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
