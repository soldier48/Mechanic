package com.design.PyMe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SignInWithSocialActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin_with_social);
    }
}
